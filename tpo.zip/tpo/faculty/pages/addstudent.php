<?php
session_start();
ob_start();

//Include the database connection file
include "../../config.php";
require "../../mail.php";
	$msg;
	$color;
	$msg1;
	$color1;
	$number=0;
	$number1=0;

if (isset($_SESSION["VALID_FACULTY"]) && !empty($_SESSION["VALID_FACULTY"])) 
 {
    //This identifies the owners of pages for Adding and Cancelling Friendship activities
    if (isset($_GET["page_owner"]) && !empty($_GET["page_owner"])) 
	{
        $page_owner = strip_tags(base64_decode($_GET["page_owner"]));
    }
	else 
	{
        $page_owner = strip_tags($_SESSION["VALID_FACULTY"]);
    }
	
	if(isset($_POST["submit"]))
	{
	
	
	$file="myfile.csv";
	if (file_exists($file))
 	{  
 		unlink($file);
 		move_uploaded_file($_FILES["file"]["tmp_name"],$file);
 	}
	else
	{
		move_uploaded_file($_FILES["file"]["tmp_name"],$file);
	}
	$row = 1;
	
	if (($handle = fopen($file, 'r')) !== FALSE)
	{
      	while (($data = fgetcsv($handle, 1000, ',')) !== FALSE)
    	{
	
			$username=$data[5];
			$password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
			$encpassword=md5($password);
			$email=$data[4];
			$mob=$data[3];
			$fname=$data[0];
			$mname=$data[1];
			$lname=$data[2];
			$class=$data[6];
			$div=$data[7];
			$dept=$_SESSION["dept"];
			$keydata=$username.$password.$email.$mob.$fname.$mname.$lname.$class.$div.$dept.$encpassword;
			$key=generatekey($keydata);
			

			mysqli_autocommit($connection1,FALSE);
			if(mysqli_query($connection1,"INSERT INTO `student`(`fname`, `mname`, `lname`, `mobile`, `email`, `photo`, `username`, `password`, `deptid`, `class`, `division`, `status`) values(AES_ENCRYPT('$fname','$key'),AES_ENCRYPT('$mname','$key'),AES_ENCRYPT('$lname','$key'),AES_ENCRYPT('$mob','$key'),AES_ENCRYPT('$email','$masterkey'),AES_ENCRYPT('avatar5.png','$key'),AES_ENCRYPT('$username','$masterkey'),'$encpassword',AES_ENCRYPT('$dept','$key'),AES_ENCRYPT('$class','$key'),AES_ENCRYPT('$div','$key'),'Active')"))
			{
				$last_id = mysqli_insert_id($connection1);
				mysqli_autocommit($connection2,FALSE);
				
				if(mysqli_query($connection2,"INSERT INTO `education`(`studentid`, `deptid`) values('$last_id','$dept')"))
				{
					if(mysqli_query($connection2,"INSERT INTO `keydata`(`studentid`, `studentkey`) VALUES ('$last_id',AES_ENCRYPT('$key','$masterkey'))"))
					{
						$number++;
						$msg=$number." User added successfully.";
						$color= "alert-success";
						mailsend($email,$password,$username,$fname);
						mysqli_commit($connection1);
						mysqli_commit($connection2);
						
					}
					else
					{	
						$number1++;
						$msg1=$number1." User Fail Please Check Information2. or Username Already Exists";
						$color1= "alert-warning";
						mysqli_rollback($connection1);
						mysqli_rollback($connection2);					
					}
				}
				else
				{
						$number1++;
						$msg1=$number1."  User Fail Please Check Information. or Username Already Exists";
						$color1= "alert-warning";
						mysqli_rollback($connection1);
						mysqli_rollback($connection2);
				}
			}
			else
			{
						$number1++;
						$msg1=$number1." User Fail Please Check Information. or Username Already Exists";
						$color1= "alert-warning";
						mysqli_rollback($connection1);
						mysqli_rollback($connection2);
		
			}
		}
	
	}}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
   <title>Add Students </title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

 
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <?php include("header.php"); ?>

  <!-- =============================================== -->

  

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Students Registration
        <small>TPO</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo "index.php?page_owner=".base64_encode($page_owner); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Students Master</a></li>
        <li class="active">Add Students</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	
        <!-- left column -->
		<div class="row">
        <div class="col-md-6">

      <!-- Default box -->
       <div class="box box-primary col-md-6">
            <div class="box-header with-border">
              <h3 class="box-title">Students Registration</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
			<?php
if(isset($msg))
{
	echo  '<div class="alert '.$color.'">
                    <ul class="margin-bottom-none padding-left-lg">
                      <li>'.$msg.'</li>
                      
                    </ul>
                 								
          </div>';
}
if(isset($msg1))
{
	echo  '<div class="alert '.$color1.'">
                    <ul class="margin-bottom-none padding-left-lg">
                      <li>'.$msg1.'</li>
                      
                    </ul>
                 								
          </div>';
}


 ?>
            <form  method="post" action="" enctype="multipart/form-data" name="frmCSVImport" id="frmCSVImport">
      <div id="labelError"></div>
	          <div class="box-body">
			  
			  <div class="form-group">
                  <label for="exampleInputEmail1">Select File To Upload</label>
                  <input type="file" class="form-control" id="file" name="file" required accept=".csv">
                </div>
				
               
              <!-- /.box-body -->

               <button type="submit" id="submit" class="btn btn-lg btn-success btn-block" name="submit" >Upload All</button>
			   <a href="../../test.csv" >Download Sample File </a>
            </form>
          </div>
        <!-- /.box-body -->
        
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  

  
    
</div>

<!-- ./wrapper -->
<script type="text/javascript">
	$(document).ready(
	function() {
		$("#frmCSVImport").on(
		"submit",
		function() {

			$("#response").attr("class", "");
			$("#response").html("");
			var fileType = ".csv";
			var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+("
					+ fileType + ")$");
			if (!regex.test($("#file").val().toLowerCase())) {
				$("#response").addClass("error");
				$("#response").addClass("display-block");
				$("#response").html(
						"Invalid File. Upload : <b>" + fileType
								+ "</b> Files.");
				return false;
			}
			return true;
		});
	});
</script>
<!-- jQuery 2.2.0 -->
<script src="../../plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>

</body>
</html>

<?php
}
else
{
//echo "hii";
echo $_SESSION["VALID_FACULTY"];
header("location: ../index.php");
}
?>
