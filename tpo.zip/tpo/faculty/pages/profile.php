<?php
session_start();
ob_start();

//Include the database connection file
include "../../config.php";

if (isset($_SESSION["VALID_USER"]) && !empty($_SESSION["VALID_USER"])) 
 {
    //This identifies the owners of pages for Adding and Cancelling Friendship activities
    if (isset($_GET["page_owner"]) && !empty($_GET["page_owner"])) 
	{
        $page_owner = strip_tags(base64_decode($_GET["page_owner"]));
    }
	else 
	{
        $page_owner = strip_tags($_SESSION["VALID_USER"]);
    }


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <title>User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <?php include("header.php"); ?>

  <!-- =============================================== -->

  

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        WelCome
        <small>SecureDB</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
<div class="row">
<div class="col-md-6">

      <!-- Default box -->
       <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Profile Details</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
              <div class="box-body">
      <?php 
				$userid=$_SESSION['VALID_USER'];
				$userkey=$_SESSION['userkey'];
				//echo "select AES_DECRYPT(fname,'$userkey') as fname, AES_DECRYPT(mname,'$userkey') as mname, AES_DECRYPT(lname,'$userkey') as lname, AES_DECRYPT(birthplace,'$userkey') as birthplace, AES_DECRYPT(birthdate,'$userkey') as birthdate, AES_DECRYPT(birthtime,'$userkey') as birthtime from `birthdata` where `user_id` = '$userid'";
		$validate_user_information = mysqli_query($connection1,"select AES_DECRYPT(fname,'$userkey') as fname, AES_DECRYPT(mname,'$userkey') as mname, AES_DECRYPT(lname,'$userkey') as lname, AES_DECRYPT(birthplace,'$userkey') as birthplace, AES_DECRYPT(birhtdate,'$userkey') as birthdate, AES_DECRYPT(birthtime,'$userkey') as birthtime from `birthdata` where `user_id` = '$userid'");
	
	
	if(mysqli_num_rows($validate_user_information) == 1) //Check if the information of the user are valid or not
	{		
				
	$get_user_information = mysqli_fetch_array($validate_user_information);
	?>
          <div class="form-group">
	    <label>Username:- </label>
        	<label><?php echo $_SESSION['VALID_USER']; ?></label>									
          </div>
		  
		  <div class="form-group">
	    <label>Name :</label>
        	<label><?php echo $get_user_information['fname']." ".$get_user_information['mname']." ".$get_user_information['lname']; ?></label>									
          </div>    
		  
		  <div class="form-group">
	    <label>Birth Place :</label>
        	<label><?php echo $get_user_information['birthplace']; ?></label>									
          </div>      
                
         <div class="form-group">
	    <label>DOB :</label>
        	<label><?php echo $get_user_information['birthdate']; ?></label>									
          </div>      
                
			<div class="form-group">
	    <label>Time :</label>
        	<label><?php echo $get_user_information['birthtime']; } ?></label>									
          </div>      
                	
			    
                		
            </div>
      
      </div>
	  </div>
</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  

  
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.0 -->
<script src="../../plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>

<?php
}
else
{
//echo "hii";
echo $_SESSION["VALID_USER"];
header("location: ../index.php");
}
?>