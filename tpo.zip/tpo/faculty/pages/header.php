﻿<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo "index.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>TPO</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TPO</b> </span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
         
        </ul>
      </div>
    </nav>
  </header>
  
  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-right info">
          <p><?php echo $_SESSION['Faculty_FULLNAME']; ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
     
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="<?php echo "index.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span> 
          </a>
          
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Student Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addstudent.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-plus"></i> Add Students </a></li>
			<li><a href="<?php echo "rptstudent.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Update Students </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Notice Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addnotice.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-cart-plus"></i> Add Notice </a></li>
			<li><a href="<?php echo "rptnotice.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-times"></i> Update Notice </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Alumni Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addalumni.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-cart-plus"></i> Add Alumni  </a></li>
									      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Report</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "rptalumni.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-plus"></i> Alumani  </a></li>
			<li><a href="<?php echo "rptstudent.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Student List </a></li>
			<li><a href="<?php echo "rptstudentacademic.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Mark List </a></li>
			<li><a href="<?php echo "rptcampus.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Campus List </a></li>
			<li><a href="<?php echo "rptplaced.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Placed List </a></li>
			<li><a href="<?php echo "rptnonplaced.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i>Non Placed List </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Profile Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "updateprofile.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-plus"></i> Update Profile </a></li>
			<li><a href="<?php echo "changepassword.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Update Password </a></li>
			<li><a href="<?php echo "logout.php?page_owner=".base64_encode($_SESSION["VALID_FACULTY"]); ?>"><i class="fa fa-user-times"></i> Logout </a></li>
						      
          </ul>
        </li>
       
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>