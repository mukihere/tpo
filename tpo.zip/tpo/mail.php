<?php
require("PHPMailerAutoload.php");
function mailsend($email,$password,$username,$name)
{
	
$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.hostinger.in";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "admin@sgutpo.online";  // SMTP username
$mail->Password = "encryptdb"; // SMTP password


$mail->Port = 587;
$mail->From = "admin@sgutpo.online";
$mail->FromName = "Online SGI TPO";
$mail->AddAddress($email);


$mail->WordWrap = 50;                                 // set word wrap to 50 characters
//$mail->AddAttachment("/var/tmp/file.tar.gz");         // add attachments
//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "Welcome to Online SGI TPO";
$mail->Body    = "Dear ".$name."  ,  <br/>

Your Account is Created at Online SGI TPO as User. <br/> We thank you for registering with us.<br/><br/>

Your login ID is :". $username."<br/>
Your Password is : ". $password."<br/><br/>
We request you to keep your login information confidential.<br/><br/>
Thanks for Showing interest in our company.<br/><br/><br/>
Regards,<br/>
Online SGI TPO Team

";
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   		/*echo '<script language="javascript">';
		//echo 'alert("Mail is Not Send.")';
		/echo '</script>';	*/
   
}
else
{
		/*echo '<script language="javascript">';
		echo 'alert("Mail has been sent to given Email-ID to get your login details.")';
		echo '</script>';*/	
}


}


function adminmailsend($email,$pwd,$name)
{
	
$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.hostinger.in";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "admin@sgutpo.online";  // SMTP username
$mail->Password = "encryptdb"; // SMTP password


$mail->Port = 587;
$mail->From = "admin@sgutpo.online";
$mail->FromName = "Online SGI TPO";
$mail->AddAddress($email, "User");

$mail->WordWrap = 50;                                 // set word wrap to 50 characters
//$mail->AddAttachment("/var/tmp/file.tar.gz");         // add attachments
//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "Welcome Online SGI TPO";
$mail->Body    = "Dear ".$name."  ,  <br/>

Your Account is Created as Admin of Online SGI TPO. <br/> We thank you for registering with us.<br/><br/>

Your login ID is :". $email."<br/>
Your Password is : ". $pwd."<br/><br/>
We request you to keep your login information confidential.<br/><br/>
Thanks for Showing interest in Online SecureDB.<br/><br/><br/>
Regards,<br/>
Online SGI TPO Team

";
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   	echo '<script language="javascript">';
		echo 'alert("Mail is Not Send.")';
		echo '</script>';	
   //exit;
}
else
{
echo '<script language="javascript">';
		echo 'alert("Mail has been sent to given Email-ID to get your login details.")';
		echo '</script>';	
}


}




//User Forgot password
function forgotmail($email,$pwd)
{
	
$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.hostinger.in";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "admin@sgutpo.online";  // SMTP username
$mail->Password = "encryptdb"; // SMTP password


$mail->Port = 587;
$mail->From = "admin@sgutpo.online";
$mail->FromName = "Online SGI TPO";
$mail->AddAddress($email);


$mail->WordWrap = 50;                                 // set word wrap to 50 characters
//$mail->AddAttachment("/var/tmp/file.tar.gz");         // add attachments
//$mail->AddAttachment("/tmp/image.jpg", "new.jpg");    // optional name
$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "Password reset  to Online SGI TPO Account";
$mail->Body    = "Dear ".$email."  ,  <br/>

Your Account Password is reset successfully at our Online SGI TPO Account. <br/> We thank you for registering with us.<br/><br/>


Your  New Password is : ". $pwd."<br/><br/>
We request you to keep your login information confidential.<br/><br/>
Thanks for Showing interest in our company.<br/><br/><br/>
Regards,<br/>
Online SGI TPO

";
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   	echo '<script language="javascript">';
		echo 'alert("Mail is Not Send.")';
		echo '</script>';	
   //exit;
echo $mail->ErrorInfo;
}
else
{
echo '<script language="javascript">';
		echo 'alert("Mail has been sent to given Email-ID to get your login details.")';
		echo '</script>';	
}


}


//notice send function

function sendnotice($emaillist,$title,$details)
{
	
$mail = new PHPMailer();

$mail->IsSMTP();                                      // set mailer to use SMTP
$mail->Host = "mx1.hostinger.in";  // specify main and backup server
$mail->SMTPAuth = true;     // turn on SMTP authentication
$mail->Username = "admin@sgutpo.online";  // SMTP username
$mail->Password = "encryptdb"; // SMTP password


$mail->Port = 587;
$mail->From = "admin@sgutpo.online";
$mail->FromName = "Online SGI TPO";
$count=0;
foreach($emaillist as $email)
{
	$count++;
	$mail->AddAddress($email);
}

$mail->WordWrap = 50;                                 // set word wrap to 50 characters

$mail->IsHTML(true);                                  // set email format to HTML

$mail->Subject = "Online SGI TPO : ".$title;
$mail->Body    = "Dear Student, <br/>".$details.

"
<br><br/><br/><br/>
We request you to keep your login information confidential.<br/><br/>
Thanks for Showing interest in our company.<br/><br/><br/>
Regards,<br/>
Online SGI TPO Team

";
$mail->AltBody = "This is the body in plain text for non-HTML mail clients";

if(!$mail->Send())
{
   		echo '<script language="javascript">';
		echo 'alert("Mail is Not Send.")';
		echo '</script>';	
   
}
else
{
		echo '<script language="javascript">';
		echo 'alert("Mail has been sent to '.$count.' students.")';
		echo '</script>';
}


}

