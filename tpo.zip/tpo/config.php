﻿<?php

$masterkey="Tpo@Sgi123";

$servername = "127.0.0.1";						//getenv('IP');
define ('hostnameorservername',$servername);	 // Server Name or host Name 
define ('serverusername','root'); // database Username 
define ('serverpassword',''); // database Password 
define ('databasename1','tpo1'); // database Name 
define ('databasename2','tpo2');
define ('databasename3','tpo3');

global $connection;
$connection1 = @mysqli_connect(hostnameorservername,serverusername,serverpassword,databasename1) or die('Connection could not be made to the SQL Server. Please report this system error at <font color="blue">admin1</font>');


$connection2 = @mysqli_connect(hostnameorservername,serverusername,serverpassword,databasename2) or die('Connection could not be made to the SQL Server. Please report this system error at <font color="blue">admin</font>');


$connection3 = @mysqli_connect(hostnameorservername,serverusername,serverpassword,databasename3) or die('Connection could not be made to the SQL Server. Please report this system error at <font color="blue">admin</font>');


// key generation
function generatekey($value)
{
	$ekey=substr(str_shuffle($value), 0, 16);
	//$key=hash ('sha512' , $value);
	return $ekey;
	
}
?>
