<?php
include "../../config.php";

$departid = $_POST['depart'];   // department id

$sql = "SELECT c.*,co.* FROM campus as c,company as co WHERE c.deptid='$departid' and c.companyid=co.company_id and c.status='Active'";

$result = mysqli_query($connection3,$sql);

$users_arr = array();

while( $row = mysqli_fetch_array($result) ){
    $campusid = $row['campusid'];
	$companyid=$row['companyid'];
    $name = $row['companyname']." ".$row['date'];

    $users_arr[] = array("id" => $campusid, "name" => $name,"companyid"=>$companyid);
}

// encoding array to json format
echo json_encode($users_arr);