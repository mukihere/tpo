<?php
session_start();
ob_start();

//Include the database connection file
include "../../config.php";

if (isset($_SESSION["VALID_ADMIN"]) && !empty($_SESSION["VALID_ADMIN"])) 
 {
    //This identifies the owners of pages for Adding and Cancelling Friendship activities
    if (isset($_GET["page_owner"]) && !empty($_GET["page_owner"])) 
	{
        $page_owner = strip_tags(base64_decode($_GET["page_owner"]));
    }
	else 
	{
        $page_owner = strip_tags($_SESSION["VALID_ADMIN"]);
    }


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap.css">
  <link rel="stylesheet" href="../../fontawesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="boxed skin-blue sidebar-mini" style="height: auto; min-height: 100%;">
<!-- Site wrapper -->
<div class= "wrapper">

  <?php include("header.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        WelCome
        <small>Admin</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
	
	
	
	 <!-- Main content -->
    <section class="content">
            
            <!-- /.row -->
            
 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection1,"SET NAMES utf8");
                  $result = mysqli_query($connection1,"SELECT *  from admin where status='Active'");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total Admin User</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptadmin.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>
 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-building  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection1,"SET NAMES utf8");
                  $result = mysqli_query($connection1,"SELECT *  from department where status='Active'");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total Departments</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptdept.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>


 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection1,"SET NAMES utf8");
                  $result = mysqli_query($connection1,"SELECT *  from faculty where status='Active' ");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total Staff User</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptstaff.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>
</section>
 <section class="content">

 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-graduation-cap  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection1,"SET NAMES utf8");
                  $result = mysqli_query($connection1,"SELECT *  from student where status='Active'");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total Students</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptstaff.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>




<div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tags  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection3,"SET NAMES utf8");
                  $result = mysqli_query($connection3,"SELECT *  from company where status='Active'");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total company's</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptcompany.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       

				</div>
				
				
				
				
				


 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bank  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
                   $result = mysqli_query($connection3,"SET NAMES utf8");
                  $result = mysqli_query($connection3,"SELECT *  from campus where status='Active' ");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total campus conducted</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptcampus.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>

</section>
 <section class="content">
 <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users  fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php 
									//$deptid=$_SESSION['dept'];
                   $result = mysqli_query($connection3,"SET NAMES utf8");
                  $result = mysqli_query($connection3,"SELECT p.*, c.*, o.companyname from placement as p,campus as c,company as o where p.companyid=c.companyid=o.company_id  and p.campusid=c.campusid ");
                  $row_cnt = mysqli_num_rows($result);
                 // $total=count(mysqli_num_rows($result));
                  echo  $row_cnt;
                                    ?></div>
                                    <div>Total placements</div>
                                </div>
                            </div>
                        </div>
                        <a href="rptplacement.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>       



</div>


	
	
	
                
                <section class="content">
	
	
	
	   
        <!-- left column -->
        <div class=" col-md-12">

      
 
		
        <!-- /.box-footer-->
      </div>
	  
	  </section>
    <!-- /.content -->
	 
	


   
  </div>
  <!-- /.content-wrapper -->

  

  
</div>

<!-- ./wrapper -->

<!-- jQuery 2.2.0 -->
<script src="../../plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $('#example1').DataTable( {
        stateSave: true
    } );
} );
</script>
</body>
</html>

<?php
}
else
{
//echo "hii";
echo $_SESSION["VALID_ADMIN"];
header("location: ../index.php");
}
?>
