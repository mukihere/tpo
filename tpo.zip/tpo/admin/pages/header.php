﻿<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo "index.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>TPO</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TPO</b> </span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
         
        </ul>
      </div>
    </nav>
  </header>
  
  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-right image">
          <img src="../../dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $_SESSION['Admin_FULLNAME']; ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
     
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="<?php echo "index.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span> 
          </a>
          
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Admin Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addadmin.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-plus"></i> Add User </a></li>
			<li><a href="<?php echo "rptadmin.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-times"></i> Update User </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Department Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "adddept.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-cart-plus"></i> Add Department </a></li>
			<li><a href="<?php echo "rptdept.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-times"></i> Update Department </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Staff Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addstaff.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-cart-plus"></i> Add Staff </a></li>
			<li><a href="<?php echo "rptstaff.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-times"></i> Update Staff </a></li>
						      
          </ul>
        </li>
		
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Student Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            
			<li><a href="<?php echo "rptstudent.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-times"></i> Update User </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Comapny Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addcompany.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-cart-plus"></i> Add Company </a></li>
			<li><a href="<?php echo "rptcompany.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-times"></i> Update Company </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Campus Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addcampus.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-cart-plus"></i> Add Campus </a></li>
			<li><a href="<?php echo "rptcampus.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-times"></i> Update Campus </a></li>
						      
          </ul>
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa  fa-bank"></i> <span>Placement Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "addplacement.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-cart-plus"></i> Add Placement </a></li>
			<li><a href="<?php echo "rptplacement.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-times"></i> Update Placement </a></li>
						      
          </ul>
        </li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Profile Master</span> <i class="fa fa-hand-o-down pull-right"></i>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo "updateprofile.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-plus"></i> Update Profile </a></li>
			<li><a href="<?php echo "changepassword.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-times"></i> Update Password </a></li>
			<li><a href="<?php echo "logout.php?page_owner=".base64_encode($_SESSION["VALID_ADMIN"]); ?>"><i class="fa fa-user-times"></i> Logout </a></li>
						      
          </ul>
        </li>
       
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>