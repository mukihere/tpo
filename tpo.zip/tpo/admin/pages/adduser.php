<?php
session_start();
ob_start();

//Include the database connection file
include "../../config.php";
require "../../mail.php";
$msg;
	$color;

if (isset($_SESSION["VALID_ADMIN"]) && !empty($_SESSION["VALID_ADMIN"])) 
 {
    //This identifies the owners of pages for Adding and Cancelling Friendship activities
    if (isset($_GET["page_owner"]) && !empty($_GET["page_owner"])) 
	{
        $page_owner = strip_tags(base64_decode($_GET["page_owner"]));
    }
	else 
	{
        $page_owner = strip_tags($_SESSION["VALID_ADMIN"]);
    }
	
	if(isset($_POST["submit"]))
	{
	
	$password = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
	$encpassword=md5($password);
	$fname=$_POST['fname'];
	$mname=$_POST['mname'];
	$lname=$_POST['lname'];
	$mother=$_POST['mother'];
	$address=$_POST['address'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$email=$_POST["email"];
	$mob=$_POST["mobile"];
	$time=$_POST["time"];
	$birth=$_POST["birth"];
	$date=$_POST["date"];
	$category=$_POST["category"];
	$caste=$_POST["caste"];
	$today=date("Y-m-d");
	$gender=$_POST['gender'];
	
	$keyvalue=$fname.$mname.$lname.$mother.$email.$date.$time.$mob.$city.$password;
	$ekey=generatekey($keyvalue);
	
			
	mysqli_autocommit($connection1,FALSE);
	if(mysqli_query($connection1,"INSERT INTO `birthdata`(`fname`, `mname`, `lname`, `birthplace`, `birhtdate`, `birthtime`, `pass`) values(AES_ENCRYPT('$fname','$ekey'),AES_ENCRYPT('$mname','$ekey'),AES_ENCRYPT('$lname','$ekey'),AES_ENCRYPT('$birth','$ekey'),AES_ENCRYPT('$date','$ekey'),AES_ENCRYPT('$time','$ekey'),AES_ENCRYPT('$password','$ekey'))"))
	{
		$last_id = mysqli_insert_id($connection1);
		mysqli_autocommit($connection2,FALSE);
		if(mysqli_query($connection2,"INSERT INTO `birthdata`(`user_id`, `mother_name`, `gender`, `mobile`, `email`, `address`, `city`, `state`, `country`, `status`) values('$last_id',AES_ENCRYPT('$mother','$ekey'),AES_ENCRYPT('$gender','$ekey'),AES_ENCRYPT('$mob','$ekey'),AES_ENCRYPT('$email','$ekey'),AES_ENCRYPT('$address','$ekey'),AES_ENCRYPT('$city','$ekey'),AES_ENCRYPT('$state','$ekey'),AES_ENCRYPT('India','$ekey'),'Active')"))
		{
			mysqli_autocommit($connection3,FALSE);
			if(mysqli_query($connection3,"INSERT INTO `birthdata`(`user_id`, `category`, `cast`, `reg_date`) VALUES('$last_id',AES_ENCRYPT('$category','$ekey'),AES_ENCRYPT('$caste','$ekey'),'$today')"))
			{
			
				if(mysqli_query($connection2,"INSERT INTO `metadata`( `user_id`, `userkey`) VALUES('$last_id',AES_ENCRYPT('$ekey','$masterkey'))"))
				{
				$msg="User added successfully.";
				$color= "alert-success";
				mysqli_commit($connection1);
				mysqli_commit($connection2);
				mysqli_commit($connection3);
				
				//mailsend($email,$username,$password,$name);
				}
				else
				{
					mysqli_rollback($connection1);
					mysqli_rollback($connection2);
					mysqli_rollback($connection3);
					$msg="Please Check Information. or Username Already Exists0";
					$color= "alert-warning";
				}
			}
				else
				{
					mysqli_rollback($connection1);
					mysqli_rollback($connection2);
					mysqli_rollback($connection3);
					$msg="Please Check Information. or Username Already Exists1";
					$color= "alert-warning";
				}
		}
		else
		{
			mysqli_rollback($connection1);
					mysqli_rollback($connection2);
					mysqli_rollback($connection3);
			$msg="Please Check Information. or Username Already Exists2";
			$color= "alert-warning";
		}
	}
	else
	{
		mysqli_rollback($connection1);
					mysqli_rollback($connection2);
					mysqli_rollback($connection3);
		$msg="Please Check Information. or Username Already Exists3";
		$color= "alert-warning";
		
	
	}
	}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
   <title>Add New User </title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9] sidebar-mini skin-blue sidebar-collapse>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif] layout-top-nav skin-purple-light-->
</head>
<body class="sidebar-mini skin-blue sidebar-collapse">
<!-- Site wrapper -->
<div class="wrapper">

  <?php include("header.php"); ?>

  <!-- =============================================== -->

  

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         User Registration
        <small>SecureDB</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo "index.php?page_owner=".base64_encode($page_owner); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">User Master</a></li>
        <li class="active">Add User</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	
        <!-- left column -->
		<div class="row">
        <div class="col-md-6">

      <!-- Default box -->
       <div class="box box-primary col-md-6">
            <div class="box-header with-border">
              <h3 class="box-title">User Registration</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
			<?php
if(isset($msg))
{
	echo  '<div class="alert '.$color.'">
                    <ul class="margin-bottom-none padding-left-lg">
                      <li>'.$msg.'</li>
                      
                    </ul>
                 								
          </div>';
}


 ?>
            <form  method="post" action="">
              <div class="box-body">
			  <div class="form-group">
                  <label for="exampleInputEmail1">First name</label>
                  <input type="text" class="form-control"  placeholder="Enter First name" name="fname" required pattern="[a-zA-Z]+">
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Middle Name</label>
                  <input type="text" class="form-control"  placeholder="Enter Middle Name" name="mname" required pattern="[a-zA-Z]+">
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Last Name</label>
                  <input type="text" class="form-control"  placeholder="Enter Last Name" name="lname" required pattern="[a-zA-Z]+">
                </div>
				<div class="form-group">
			  <label for="exampleInputEmail1">Mother name</label>
                  <input type="text" class="form-control"  placeholder="Enter Mother name" name="mother" required pattern="[a-zA-Z]+">
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Gender</label>
                  <select class="form-control" name="gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                   </select>
                </div>
				<div class="form-group">
                  <label>Address</label>
                  <textarea class="form-control" rows="3" placeholder="Enter Address" name="address"></textarea>
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">City</label>
                  <input type="text" class="form-control"  placeholder="Enter City" name="city" required pattern="[a-zA-Z]+">
                </div>
				<div class="form-group">
				<label for="exampleInputEmail1">State * </label>
    <select name="state" class="form-control" required="">
      <option value="ANDAMAN AND NICOBAR ISLANDS">ANDAMAN AND NICOBAR ISLANDS</option>
      <option value="ANDHRA PRADESH">ANDHRA PRADESH</option>
      <option value="ARUNACHAL PRADESH">ARUNACHAL PRADESH</option>
      <option value="ASSAM">ASSAM</option>
      <option value="BIHAR">BIHAR</option>
      <option value="CHANDIGARH">CHANDIGARH</option>
      <option value="CHHATTISGARH">CHHATTISGARH</option>
      <option value="DADRA AND NAGAR HAVELI">DADRA AND NAGAR HAVELI</option>
      <option value="DAMAN AND DIU">DAMAN AND DIU</option>
      <option value="DELHI">DELHI</option>
      <option value="GOA">GOA</option>
      <option value="GUJARAT">GUJARAT</option>
      <option value="HARYANA">HARYANA</option>
      <option value="HIMACHAL PRADESH">HIMACHAL PRADESH</option>
      <option value="JAMMU AND KASHMIR">JAMMU AND KASHMIR</option>
      <option value="JHARKHAND">JHARKHAND</option>
      <option value="KARNATAKA">KARNATAKA</option>
      <option value="KERALA">KERALA</option>
      <option value="LAKSHADWEEP">LAKSHADWEEP</option>
      <option value="MADHYA PRADESH">MADHYA PRADESH</option>
      <option value="MAHARASHTRA">MAHARASHTRA</option>
      <option value="MEGHALAYA">MEGHALAYA</option>
      <option value="MIZORAM">MIZORAM</option>
      <option value="NAGALAND">NAGALAND</option>
      <option value="ODISHA">ODISHA</option>
      <option value="PUDUCHERRY">PUDUCHERRY</option>
      <option value="PUNJAB">PUNJAB</option>
      <option value="RAJASTHAN">RAJASTHAN</option>
      <option value="SIKKIM">SIKKIM</option>
      <option value="TAMIL NADU">TAMIL NADU</option>
      <option value="TELANGANA">TELANGANA</option>
      <option value="TRIPURA">TRIPURA</option>
      <option value="UTTARAKHAND">UTTARAKHAND</option>
      <option value="UTTAR PRADESH">UTTAR PRADESH</option>
      <option value="WEST BENGAL">WEST BENGAL</option>
    </select>
				</div>
			  
			   
				
		  	<div class="form-group">
                  <label for="exampleInputEmail1">Mobile</label>
                  <input type="number" class="form-control" placeholder="Enter Mobile" name="mobile" required pattern="[0-9]{10}">
                </div>
				
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control"  placeholder="Enter email" name="email" required>
                </div>
				          
                <div class="form-group">
                  <label for="exampleInputEmail1">Birth Place</label>
                  <input type="text" class="form-control"  placeholder="Enter Birth Place" name="birth" required pattern="[a-zA-Z]+">
                </div>
             <div class="form-group">
                  <label for="exampleInputEmail1">Birth Date</label>
                  <input type="date" class="form-control"  placeholder="Enter Birth Date" name="date" required >
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Birth Time</label>
                  <input type="time" class="form-control"  placeholder="Enter Birth Time" name="time" required>
                </div>
				
				<div class="form-group">
				<label for="exampleInputEmail1">Category </label>
    				<select name="category" class="form-control" required>
      					<option value="Open">Open </option>
	   					<option value="OBC">OBC </option>
	   					<option value="SC">SC </option>
		 				<option value="NT">NT </option>
		  				<option value="Other">Other </option>
	  				</select>
	 			 </div>
				 <div class="form-group">
                  <label for="exampleInputEmail1">Caste</label>
                  <input type="text" class="form-control"  placeholder="Enter Caste" name="caste" required pattern="[a-zA-Z]+">
                </div>
              <!-- /.box-body -->

               <button type="submit" class="btn btn-lg btn-success btn-block" name="submit" >Register Me</button>
            </form>
          </div>
        <!-- /.box-body -->
        
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  

  
    
</div>

<!-- ./wrapper -->

<!-- jQuery 2.2.0 -->
<script src="../../plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>

</body>
</html>

<?php
}
else
{
//echo "hii";
echo $_SESSION["VALID_ADMIN"];
header("location: ../index.php");
}
?>
